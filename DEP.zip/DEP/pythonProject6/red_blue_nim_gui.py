import tkinter as tk
from tkinter import messagebox
import sys

def evaluate_score(num_red, num_blue):
    return num_red * 2 + num_blue * 3

def is_game_over(num_red, num_blue, version):
    if version == 'standard':
        return num_red == 0 or num_blue == 0
    elif version == 'misere':
        return num_red == 0 or num_blue == 0
    return False

def min_max_algorithm(num_red, num_blue, depth, is_maximizing, alpha, beta):
    if is_game_over(num_red, num_blue, 'standard'):
        return evaluate_score(num_red, num_blue) if is_maximizing else -evaluate_score(num_red, num_blue)

    if depth == 0:
        return evaluate_score(num_red, num_blue)

    if is_maximizing:
        max_eval = float('-inf')
        for red_pick in range(num_red + 1):
            for blue_pick in range(num_blue + 1):
                if red_pick + blue_pick > 0:
                    new_num_red = num_red - red_pick
                    new_num_blue = num_blue - blue_pick
                    eval = min_max_algorithm(new_num_red, new_num_blue, depth - 1, False, alpha, beta)
                    if eval > max_eval:
                        max_eval = eval
                    alpha = max(alpha, eval)
                    if beta <= alpha:
                        break
        return max_eval
    else:
        min_eval = float('inf')
        for red_pick in range(num_red + 1):
            for blue_pick in range(num_blue + 1):
                if red_pick + blue_pick > 0:
                    new_num_red = num_red - red_pick
                    new_num_blue = num_blue - blue_pick
                    eval = min_max_algorithm(new_num_red, new_num_blue, depth - 1, True, alpha, beta)
                    if eval < min_eval:
                        min_eval = eval
                    beta = min(beta, eval)
                    if beta <= alpha:
                        break
        return min_eval

def computer_move(num_red, num_blue, depth):
    best_move = (0, 0)
    best_score = float('-inf')
    for red_pick in range(num_red + 1):
        for blue_pick in range(num_blue + 1):
            if red_pick + blue_pick > 0:
                new_num_red = num_red - red_pick
                new_num_blue = num_blue - blue_pick
                score = min_max_algorithm(new_num_red, new_num_blue, depth, False, float('-inf'), float('inf'))
                print(f"Testing move: Red: {red_pick}, Blue: {blue_pick}, Score: {score}")  # Debug line
                if score > best_score:
                    best_score = score
                    best_move = (red_pick, blue_pick)
    return best_move

def player_turn():
    global num_red, num_blue, first_player
    try:
        red_pick = int(red_entry.get())
        blue_pick = int(blue_entry.get())
        if 0 <= red_pick <= num_red and 0 <= blue_pick <= num_blue and (red_pick + blue_pick) > 0:
            num_red -= red_pick
            num_blue -= blue_pick
            if is_game_over(num_red, num_blue, version):
                messagebox.showinfo("Game Over", "You won! Final Score: " + str(evaluate_score(num_red, num_blue)))
                root.quit()
                return
            first_player = 'computer'
            update_display()
            computer_turn()
        else:
            messagebox.showwarning("Invalid Move", "Invalid input, try again.")
    except ValueError:
        messagebox.showwarning("Invalid Input", "Please enter valid integers.")

def computer_turn():
    global num_red, num_blue, first_player
    red_pick, blue_pick = computer_move(num_red, num_blue, depth)
    num_red -= red_pick
    num_blue -= blue_pick
    print(f"Computer picked {red_pick} red marbles and {blue_pick} blue marbles.")
    if is_game_over(num_red, num_blue, version):
        messagebox.showinfo("Game Over", "Computer won! Final Score: " + str(evaluate_score(num_red, num_blue)))
        root.quit()
        return
    first_player = 'human'
    update_display()

def update_display():
    red_label.config(text=f"Red Marbles: {num_red}")
    blue_label.config(text=f"Blue Marbles: {num_blue}")

def main():
    global num_red, num_blue, version, depth, first_player, root

    if len(sys.argv) < 5:
        print("Usage: python red_blue_nim_gui.py <num-red> <num-blue> <version> <first-player> [<depth>]")
        return

    num_red = int(sys.argv[1])
    num_blue = int(sys.argv[2])
    version = sys.argv[3]
    first_player = sys.argv[4]
    depth = int(sys.argv[5]) if len(sys.argv) > 5 else 3

    root = tk.Tk()
    root.title("Red-Blue Nim Game")

    tk.Label(root, text="Number of red marbles to pick:").pack()
    global red_entry
    red_entry = tk.Entry(root)
    red_entry.pack()

    tk.Label(root, text="Number of blue marbles to pick:").pack()
    global blue_entry
    blue_entry = tk.Entry(root)
    blue_entry.pack()

    tk.Button(root, text="Submit Move", command=player_turn).pack()

    global red_label, blue_label
    red_label = tk.Label(root, text=f"Red Marbles: {num_red}")
    red_label.pack()
    blue_label = tk.Label(root, text=f"Blue Marbles: {num_blue}")
    blue_label.pack()

    if first_player == 'computer':
        root.after(1000, computer_turn)

    root.mainloop()

if __name__ == "__main__":
    main()
