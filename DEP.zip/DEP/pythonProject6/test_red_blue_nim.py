import unittest
from red_blue_nim import evaluate_score, is_game_over, min_max_algorithm

class TestRedBlueNim(unittest.TestCase):

    def test_evaluate_score(self):
        self.assertEqual(evaluate_score(5, 3), 19)
        self.assertEqual(evaluate_score(0, 0), 0)
        self.assertEqual(evaluate_score(1, 1), 5)

    def test_is_game_over_standard(self):
        self.assertTrue(is_game_over(0, 5, 'standard'))
        self.assertTrue(is_game_over(5, 0, 'standard'))
        self.assertFalse(is_game_over(3, 4, 'standard'))

    def test_is_game_over_misere(self):
        self.assertTrue(is_game_over(0, 5, 'misere'))
        self.assertTrue(is_game_over(5, 0, 'misere'))
        self.assertFalse(is_game_over(3, 4, 'misere'))

    def test_min_max_algorithm(self):
        # Adjust these values based on expected behavior
        self.assertEqual(min_max_algorithm(1, 1, 1, True, float('-inf'), float('inf')), 5)
        self.assertEqual(min_max_algorithm(2, 2, 1, False, float('-inf'), float('inf')), 0)

if __name__ == "__main__":
    unittest.main()
