import requests
from bs4 import BeautifulSoup
import csv

# URL of the website to scrape
url = "https://www.citypopulation.de/en/pakistan/admin/7__punjab/"

# Send a GET request to the website
response = requests.get(url)
response.raise_for_status()  # Check if the request was successful

# Parse the HTML content using BeautifulSoup
soup = BeautifulSoup(response.text, 'html.parser')

# Find the table containing the data
table = soup.find('table', {'class': 'data'})

# Prepare lists to store the extracted data
name_list = []
status_list = []
population_list = []

# Iterate over the rows of the table
for row in table.find_all('tr')[1:]:  # Skip the header row
    cols = row.find_all('td')

    if len(cols) >= 3:
        name = cols[1].text.strip()  # Extract the name
        status = cols[2].text.strip()  # Extract the status
        population = cols[3].text.strip()  # Extract the population

        name_list.append(name)
        status_list.append(status)
        population_list.append(population)

# Write the extracted data to a CSV file
with open('punjab_population_data.csv', 'w', newline='',
          encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Name', 'Status', 'Population'])  # Write the header row

    for name, status, population in zip(name_list, status_list,
                                        population_list):
        writer.writerow([name, status, population])

print(
    "Data has been successfully scraped and saved to 'punjab_population_data.csv'"
)
